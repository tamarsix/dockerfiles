# pytan-integrations

Various web-portal integrations created using pytan. Many of these were created under an older version of pytan, and would require some updating. They are presented here for workflow examples.

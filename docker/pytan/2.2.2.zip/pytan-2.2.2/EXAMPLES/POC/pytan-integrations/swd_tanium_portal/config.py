# configure me
config = {
    'pytan_dir': '/Users/jolsen/gh/pytan/lib',
    'tanium_username': 'Tanium User',
    'tanium_password': 'T@n!um',
    'tanium_host': '172.16.31.128',
    'max_data_age': 60,
}

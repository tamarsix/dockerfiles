#!/usr/bin/python
import cgi
cgi.test()

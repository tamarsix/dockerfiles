This directory contains a number of Proof of Concepts. 

Generally speaking, these POC's will not be immediately useful to anyone right out of the box, but they will show how certain workflows could be automated using pytan.
